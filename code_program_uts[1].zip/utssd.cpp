#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode(int x) : val(x), next(NULL) {}
};

int getDecimalValue(ListNode* head) {
    int decimal = 0;
    while (head != NULL) {
        decimal <<= 1;
        decimal += head->val;
        head = head->next;
    return decimal;
}

int main() {
    ListNode *head = new ListNode(1);
    head->next = new ListNode(0);
    head->next->next = new ListNode(1);
    cout << "Binary number represented by linked list: 1 -> 0 -> 1" << endl;
    cout << "Decimal value of the binary number: " << getDecimalValue(head) << endl;
    return 0;
}
