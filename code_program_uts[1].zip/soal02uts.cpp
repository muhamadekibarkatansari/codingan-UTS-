#include <iostream>
#include <stack>
using namespace std;

int main() {
    int decimal;
    stack<char> hex;

    // Input bilangan desimal
    cout << "Masukkan bilangan desimal: ";
    cin >> decimal;

    // Konversi bilangan desimal ke bilangan heksadesimal
    while (decimal > 0) {
        int remainder = decimal % 16;
        if (remainder < 10) {
            hex.push(remainder + '0');
        } else {
            hex.push(remainder + 55);
        }
        decimal /= 16;
    }

    // Tampilkan hasil konversi
    cout << "Bilangan heksadesimal: ";
    while (!hex.empty()) {
        cout << hex.top();
        hex.pop();
    }
    cout << endl;

    return 0;
}
